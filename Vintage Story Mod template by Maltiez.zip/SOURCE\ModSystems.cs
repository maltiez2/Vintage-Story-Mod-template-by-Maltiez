﻿using Vintagestory.API.Common;

namespace $projectname$;

public sealed class $projectname$ModSystem : ModSystem
{

}